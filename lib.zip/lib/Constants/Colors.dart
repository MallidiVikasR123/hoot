// ignore_for_file: file_names

import 'package:flutter/material.dart';

class AppColors {
  static Color logoGreen = const Color(0xff008738);
  static Color logoYellow = const Color(0xffFFBB00);
  static Color logoLightGreen = const Color(0xff72bd20);

  static Color primaryShapeColor = const Color(0xff008730);
  static Color secondaryShapeColor = const Color(0xff95CD7C);
}
