import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hoot/Constants/Colors.dart';
import 'package:hoot/Screens/Hoot/Reading_Comperhension/reading_comperhension.dart';
import 'package:hoot/Screens/Hoot/STT_TESTING.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              AppBar(
                title: Text('HOOT',textScaler: const TextScaler.linear(1), style: TextStyle(letterSpacing: 1,fontSize: 22,color: AppColors.logoGreen,fontWeight: FontWeight.w900),),
                centerTitle: true,
              ),
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // Two items per row
                    crossAxisSpacing: 10.0,
                    mainAxisSpacing: 10.0,
                    childAspectRatio: 1.5, // Aspect ratio for card height (120px height)
                  ),
                  itemCount: 1,
                  itemBuilder: (context, index) {
                    List<String> buttonTitles = [
                      "Reading Comprehension",
                      "Passage Reconstruction",
                      "Give UR Opinion",
                      "Opinion",
                      "Reading",
                    ];
                
                    List<Widget> destinations = [
                      const ReadingComprehension1(),
                    ];

                    List<IconData> buttonIcons = [
                      Icons.menu_book,
                      Icons.map_outlined,           // Using 'build' as alternative
                      Icons.feedback,
                      Icons.edit,
                      Icons.chrome_reader_mode,           // Using 'build' as alternative
                    ];   

                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => destinations[index]),
                        );
                      },
                      child: Card(
                        shadowColor: AppColors.logoGreen,
                        elevation: 10,
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              Align(alignment: const Alignment(-0.9, -0.9), 
                              child: Text(
                                  buttonTitles[index],
                                  textScaler: const TextScaler.linear(0.9),
                                  textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: TextStyle(color: AppColors.logoGreen.withOpacity(0.9),fontWeight: FontWeight.bold),
                                )
                              ),
                              const Spacer(),
                              Row(
                                children: [
                                  const Spacer(),
                                  Icon(buttonIcons[index],color: AppColors.logoGreen,size: 45,),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.surround_sound_outlined),
          onPressed: () {
            Get.to(() => const MyTTSTesting());
          }),
    );
  }
}
