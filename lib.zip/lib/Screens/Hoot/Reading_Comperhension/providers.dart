// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';

class ReadingComprehensionProvider extends ChangeNotifier {
  bool _micState = true;

  bool get micState  => _micState;

  void setMicState(bool value) {
    _micState = value;
    notifyListeners();
  }

}