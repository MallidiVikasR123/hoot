// ignore_for_file: non_constant_identifier_names, camel_case_types
import 'dart:async';
import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:hoot/Constants/Colors.dart';
import 'package:hoot/Constants/loaders.dart';
import 'package:http/http.dart' as http;
import 'package:lottie/lottie.dart';
import 'package:percent_indicator/percent_indicator.dart';


class ReadingComprehension1 extends StatefulWidget {
  const ReadingComprehension1({super.key});
  @override
  State<ReadingComprehension1> createState() => _ReadingComprehensionState();
}

class _ReadingComprehensionState extends State<ReadingComprehension1> {
  bool micState = true;
  // Page and Question Management
  int num = 0;
  int totalQuestionCount = 0;
  final PageController _pageController = PageController();
  int pgCount = 0;
  int selectedOption = -1;

  // Timer Management
  late int timeLeft;
  int counter = 30;
  Timer? timer1;
  Timer? timer2;
  late int minutes;
  late int seconds;

  // Quiz Status
  double? value;
  bool finished = false;
  late String set_id;
  bool noQuesAvaliable = false;
  String roll_no = '4';

  //Passage Container
  String? passage;
  bool isLoading = false;
  List<Map<String, dynamic>> questions = [];
  List<int> userAnswers = []; // Stores user’s answers
  List<int> Answers = []; // Correct answer indices
  int duration = 0; // Total time taken
  bool nextPressed = false;
  List<dynamic> RCScore = [];
  bool _isExpanded = false;
  bool timeOver = false;
  bool _showRules = false;
  bool viewStats = false;
  double accuracy = 10;

  void resetQuizState() {
    num = 0;
    pgCount = 0;
    selectedOption = -1;
    finished = false;
    noQuesAvaliable = false;
    counter = 30;
    questions = [];
    userAnswers = [];
    Answers = [];
    duration = 0;
    nextPressed = false;
    RCScore = [];
    _isExpanded = false;
    timeOver = false;
    _showRules = false;
    viewStats = false;
    accuracy = 10;
    isLoading = true;
  }

  Future<bool> isConnected() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult != ConnectivityResult.none;
  }

  Future<void> getPassage() async {
    if (!await isConnected()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No internet connection')),
      );
      return;
    }
    setState(resetQuizState);
    try {
      final response = await http.post(
        Uri.parse(
            'http://node.technicalhub.io:4001/api/readingcomprehension-random-question'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"roll_no": roll_no}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        set_id = data["_id"];
        setState(() {
          passage = data['set'][0]['passage'];
          questions =
              List<Map<String, dynamic>>.from(data['set'][0]['questions']);
          totalQuestionCount = questions.length;
          Answers = questions.map((q) {
            // Find the index of the correct answer by checking the options.
            return [q['option1'], q['option2'], q['option3'], q['option4']]
                .indexOf(q['answer']);
          }).toList();
          timeLeft = 70;
          timerStart();
          isLoading = false;
        });
      } else {
        if (response.statusCode == 404) {
          setState(() {
            noQuesAvaliable = true;
            isLoading = false;
          });
        } else {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to fetch data')),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching passage: $e')),
      );
    }
  }

  // On submission, calculate the result and navigate to the evaluation page
  void handleSubmit() async {
    int correctAnswers = 0;

    // Compare user's answers with the correct ones
    for (int i = 0; i < questions.length; i++) {
      if (Answers[i] == userAnswers[i]) {
        correctAnswers++;
      }
    }
    setState(() {
      accuracy = ((correctAnswers / totalQuestionCount) * 100);
    });
    try {
      final response = await http.post(
        Uri.parse(
            'http://node.technicalhub.io:4001/api/readingcomprehension-submitTest'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "set_id": set_id,
          "roll_no": roll_no,
          "accuracy": "${(correctAnswers / totalQuestionCount) * 100}",
          "duration": "$duration"
        }),
      );

      // Navigate to the submission page with the score and total questions
      if (response.statusCode >= 200 && response.statusCode < 300) {
        callSubmitApi();
      } else {
        if (response.statusCode == 404) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No score found for the roll number')),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error submitting: $e')),
      );
    }
  }

  void callSubmitApi() async {
    setState(() {
      micState = true;
    });
    try {
      final RCscore_response = await http.post(
        Uri.parse(
            'http://node.technicalhub.io:4001/api/readingcomprehension-all-submissions'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"roll_no": roll_no}),
      );
      if (RCscore_response.statusCode == 200) {
        setState(() {
          RCScore = jsonDecode(RCscore_response.body);
        });
      } else {
        if (RCscore_response.statusCode == 404) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Retreiving Failed')),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching Submission Data: $e')),
      );
    }
  }

  void timerStart() {
    timer1 = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        timeLeft--;
        if (timeLeft <= 0) {
          timer1!.cancel();
          timeOver = true;
          num++;
          minutes = 0;
          seconds = 0;
          startQuizTimer();
        }
      });
    });
  }

  void startQuizTimer() {
    timer2 = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        counter--;
        if (counter < 1) {
          if (nextPressed == false) duration += 30;
          nextPressed = false;
          counter = 30;
          if (num == totalQuestionCount) {
            if (selectedOption == -1) {
              userAnswers.add(-2);
            }
            finished = true;
            timeLeft = 30;
            counter = 0;
            timer2!.cancel();
          } else {
            pgCount++;
            _pageController.animateToPage(
              pgCount,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut, // Smooth sliding transition
            );
            num++;
            if (selectedOption == -1) {
              userAnswers.add(-2);
            }
            selectedOption = -1;
          }
        }
      });
    });
  }

  // TimerRow widget for reuse
  Widget TimerRow(String title, int time, Color color) {
    int minutes = time ~/ 60;
    int seconds = time % 60;

    return Row(
      children: [
        SizedBox(
            width: MediaQuery.sizeOf(context).width * 0.5,
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.black45,
              ),
              overflow: TextOverflow.ellipsis,
              textScaler: const TextScaler.linear(1.2),
            )),
        const Spacer(),
        (timeLeft <= 0 || num == totalQuestionCount) &&
                title == 'Read' &&
                timeOver
            ? const Text('')
            : Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                    color: AppColors.logoGreen,
                    borderRadius: BorderRadius.circular(10)),
                child: Row(
                  children: [
                    const Icon(
                      Icons.timer,
                      size: 20,
                      color: Colors.white,
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Text(
                      " 0$minutes:${(seconds > 9) ? seconds : "0$seconds"}",
                      textScaler: const TextScaler.linear(1),
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: color,
                          fontSize: 12),
                    ),
                  ],
                ),
              )
      ],
    );
  }

  Widget _buildMainCard() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 10,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Improve Your English Speaking Skills',
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[900]?.withGreen(1)),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'The Reading Comprehension module enhances critical thinking by helping users understand, analyze, and interpret texts effectively.',
                      style: TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 20),
                    _buildBenefitsList(),
                    const SizedBox(height: 20),
                    _buildRulesSection(),
                    const SizedBox(height: 20),
                    _buildActionButtons(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBenefitsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Benefits:',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        _buildBenefitItem('Improve quick thinking in English'),
        _buildBenefitItem('Enhance listening comprehension'),
        _buildBenefitItem('Practice concise and accurate responses'),
        _buildBenefitItem('Get AI-powered feedback on your answers'),
        _buildBenefitItem('Track your progress over time'),
      ],
    );
  }

  Widget _buildBenefitItem(String benefit) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  top: 3.0), // Fine-tune this value if needed
              child: Icon(Icons.check_circle,
                  color: AppColors.logoGreen, size: 18),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                benefit,
                style: const TextStyle(
                    fontSize: 16,
                    height: 1.4), // Adjust line height for better readability
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRulesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () {
            setState(() {
              _showRules = !_showRules;
            });
          },
          child: Row(
            children: [
              const Text(
                'Module Rules',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Icon(_showRules ? Icons.expand_less : Icons.expand_more),
            ],
          ),
        ),
        if (_showRules)
          Padding(
            padding: const EdgeInsets.only(top: 10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildRuleItem(
                    'Listen to simple questions (e.g., "Will you eat a shoe or an apple?")'),
                _buildRuleItem('You have 10 seconds to respond'),
                _buildRuleItem('Answer in 1-2 words or a short sentence'),
                _buildRuleItem(
                    'AI analyzes your answer for accuracy and relevance'),
                _buildRuleItem(
                    'Your performance data is stored for progress tracking'),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildRuleItem(String rule) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('• ',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Expanded(child: Text(rule, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ElevatedButton.icon(
          onPressed: () {
            // Start the module
            setState(() {
              micState = false;
            });
            getPassage();
          },
          icon: const Icon(
            Icons.play_arrow,
            color: Colors.white,
          ),
          label:
              const Text('Start Module', style: TextStyle(color: Colors.white)),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.logoGreen,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
        ),
        ElevatedButton.icon(
          onPressed: () {
            // View statistics
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => StatisticsScreen(
                  RCScore: RCScore,
                ),
              ),
            );
          },
          icon: const Icon(Icons.bar_chart, color: Colors.white),
          label:
              const Text('View Stats', style: TextStyle(color: Colors.white)),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.logoYellow,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildNoQuestionsAvailable() {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Lottie animation (optional)
            Lottie.asset(
              'assets/Lottie/empty.json',
              width: 200,
              height: 200,
            ),
            const SizedBox(height: 20),
            // No questions text
            const Text(
              'No Questions Available',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            // Instruction or helpful message
            const Text(
              'Please check back later or contact support if the issue persists.',
              style: TextStyle(fontSize: 14, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            // Refresh button
            ElevatedButton(
              onPressed: getPassage, // Retry fetching questions
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade600,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Text('Retry',
                    style: TextStyle(fontSize: 16, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubmissionSuccess() {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 40),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.logoGreen, width: 2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                children: [
                  Image.asset(
                    "assets/reading_comprehension.png", // Change the image accordingly.
                    height: 140,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Submitted Successfully',
                    textScaler: const TextScaler.linear(1),
                    style: TextStyle(
                      color: AppColors.primaryShapeColor,
                      fontSize: 24,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Check out the report below, so that it will help to improve your performance.',
                    textAlign: TextAlign.center,
                    textScaler: const TextScaler.linear(1),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Accuracy Bar
                  Row(
                    children: [
                      const Text('Accuracy',
                          textScaler: TextScaler.linear(1),
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(
                        width: 135,
                      ),
                      Text('$accuracy%',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.green)),
                    ],
                  ),
                  LinearPercentIndicator(
                    percent: accuracy / 100,
                    backgroundColor: Colors.grey[300],
                    progressColor: Colors.green,
                    lineHeight: 8,
                    barRadius: const Radius.circular(10),
                    animation: true,
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
            const SizedBox(height: 50),
            // Buttons for Home
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: handleSubmit,
                  child: Container(
                    height: 60,
                    width: 140,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: const Color(0xff008738)),
                    child: const Center(
                      child: Text('Home',
                          style: TextStyle(color: Colors.white, fontSize: 18)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildreadComprehensionScreen() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.only(top: 10, left: 16, right: 16),
        child: Column(children: [
          const Align(
              alignment: Alignment(-1, 0),
              child: Text(
                'Instructions',
                textScaler: TextScaler.linear(1.2),
                style: TextStyle(fontWeight: FontWeight.bold),
              )),
          const Text(
            'You are given with a reading passage and will asked 2 questions giving options to each. You must answer them.',
            textScaler: TextScaler.linear(1.12),
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              const Text(
                'Questions',
                textScaler: TextScaler.linear(1.2),
                style: TextStyle(
                    color: Colors.black45, fontWeight: FontWeight.w600),
              ),
              const SizedBox(
                width: 15,
              ),
              Text(
                num < 10
                    ? '0$num/0$totalQuestionCount'
                    : '$num/$totalQuestionCount',
                textScaler: const TextScaler.linear(1.1),
                style: TextStyle(
                    color: AppColors.logoLightGreen,
                    fontWeight: FontWeight.bold),
              )
            ],
          ),
          const SizedBox(
            height: 6,
          ),
          LinearProgressIndicator(
            value: value! / totalQuestionCount,
            color: AppColors.logoGreen,
            backgroundColor: AppColors.logoYellow,
            minHeight: 10,
            borderRadius: BorderRadius.circular(10),
          ),
          SizedBox(
            height: timeLeft > 0 ? 100 : 30,
          ),
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: AppColors.secondaryShapeColor.withOpacity(0.2),
              border: Border.all(
                color: AppColors.logoGreen,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TimerRow('Read', timeLeft, Colors.white),
                  Container(
                    margin:
                        EdgeInsets.only(top: timeLeft > 0 ? 10 : 2, bottom: 15),
                    width: double.infinity,
                    height: timeLeft <= 0 ? 200 : null,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(12),
                        bottomLeft: Radius.circular(12),
                        bottomRight: Radius.circular(12),
                      ),
                      color: Colors.white,
                      border: Border.all(
                        color: timeLeft > 0 ? Colors.green : Colors.grey,
                      ),
                      boxShadow: [
                        BoxShadow(
                            color:
                                timeLeft > 0 ? Colors.grey : Colors.transparent,
                            blurRadius: 20,
                            spreadRadius: 1,
                            offset: const Offset(5, 10)),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: SingleChildScrollView(
                        child: Text(
                          passage ?? 'Loading passage...',
                          style: const TextStyle(
                            color: Color.fromARGB(255, 120, 119, 119),
                          ),
                          textAlign: TextAlign.left,
                          textScaler: const TextScaler.linear(1.2),
                        ),
                      ),
                    ),
                  ),
                  if (timeLeft <= 0) ...[
                    TimerRow('Answer the questions', counter, Colors.white),
                    const SizedBox(height: 5),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: SizedBox(
                        width: double.infinity,
                        height: 250,
                        child: PageView.builder(
                          controller: _pageController,
                          itemCount: totalQuestionCount,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            final question = questions[index];
                            final options = [
                              question['option1'],
                              question['option2'],
                              question['option3'],
                              question['option4'],
                            ];
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Display the question
                                Text(
                                  '${index + 1} : ${question['Q']}',
                                  style: TextStyle(
                                    fontSize: 13,
                                    wordSpacing: 0.8,
                                    color: Colors.black.withOpacity(0.75),
                                    fontWeight: FontWeight.w600,
                                  ),
                                  textScaler: const TextScaler.linear(1.2),
                                ),
                                // Wrapping the radio options in a Scrollable Widget
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Column(
                                      children: List.generate(options.length,
                                          (optionIndex) {
                                        return RadioListTile<int>(
                                          title: Text(
                                            options[optionIndex],
                                            style: const TextStyle(
                                              color: Colors.black87,
                                            ),
                                          ),
                                          value: optionIndex,
                                          groupValue: selectedOption,
                                          onChanged: (int? value) {
                                            setState(() {
                                              selectedOption = value!;
                                              // Store the answer for the current question
                                              if (userAnswers.length >
                                                  pgCount) {
                                                userAnswers[pgCount] =
                                                    selectedOption;
                                              } else {
                                                userAnswers.add(selectedOption);
                                              }
                                            });
                                          },
                                          activeColor: AppColors.logoGreen,
                                        );
                                      }),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          timeLeft > 60 && num != totalQuestionCount
              ? const SizedBox(
                  height: 20,
                )
              : Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: GestureDetector(
                    onTap: timeLeft > 0 && num != totalQuestionCount
                        ? () {
                            setState(() {
                              timeOver = true;
                              timeLeft = 0;
                            });
                          }
                        : finished
                            ? () {
                                int correctAnswers = 0;
                                // Compare user's answers with the correct ones
                                for (int i = 0; i < questions.length; i++) {
                                  if (Answers[i] == userAnswers[i]) {
                                    correctAnswers++;
                                  }
                                }
                                setState(() {
                                  accuracy =
                                      ((correctAnswers / totalQuestionCount) *
                                          100);
                                  _isExpanded = true;
                                });
                              }
                            : () {
                                setState(() {
                                  duration += 30 - counter;
                                  nextPressed = true;
                                  counter = 0;
                                });
                              },
                    child: Container(
                      width: 100,
                      height: 50,
                      decoration: BoxDecoration(
                          color: AppColors.logoGreen,
                          borderRadius: BorderRadius.circular(25)),
                      child: Center(
                        child: Text(
                            timeLeft > 0 && num != totalQuestionCount
                                ? 'Start Quiz'
                                : finished == false
                                    ? 'Next'
                                    : 'Submit',
                            textScaler: const TextScaler.linear(1.1),
                            style: const TextStyle(color: Colors.white)),
                      ),
                    ),
                  ),
                ),
        ]),
      ),
    );
  }

  Widget _buildBody() {
    if (micState) {
      return _buildMainCard();
    } else if (isLoading) {
      return Center(child: Loaders.circleLottieLoader());
    } else if (noQuesAvaliable) {
      return _buildNoQuestionsAvailable();
    } else if (_isExpanded) {
      return _buildSubmissionSuccess();
    } else {
      return _buildreadComprehensionScreen();
    }
  }

  @override
  void initState() {
    super.initState();
    callSubmitApi();
  }

  @override
  void dispose() {
    if (timer1 != null) timer1?.cancel();
    if (timer2 != null) timer2?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    value = double.parse(num.toString());
    return Scaffold(
      appBar: isLoading
          ? null
          : AppBar(
              backgroundColor: Colors.green.shade600.withOpacity(0.9),
              foregroundColor: Colors.white,
              title: const Text(
                'Reading Comprehension',
                textScaler: TextScaler.linear(1),
              ),
              centerTitle: true,
            ),
      body: _buildBody(),
    );
  }
}

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key, required this.RCScore});
  final List<dynamic> RCScore;
  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  int? _expandedTileIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade600.withOpacity(0.9),
        foregroundColor: Colors.white,
        title: const Text(
          'Reading Comprehension',
          textScaler: TextScaler.linear(1),
        ),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: widget.RCScore.length,
        itemBuilder: (BuildContext context, int ind) {
          final score = widget.RCScore[ind];
          return Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 12.0, vertical: 12.0),
            child: ExpansionTile(
              key: UniqueKey(),
              title: Text(
                score["name"] ?? "N/A",
                textScaler: const TextScaler.linear(1.0),
                style: const TextStyle(
                    color: Colors.black, fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                score["date"] ?? "No Date",
                textScaler: const TextScaler.linear(1.0),
              ),
              shape: const RoundedRectangleBorder(
                side: BorderSide(width: 1.5, color: Color(0xff008738)),
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
              collapsedShape: const RoundedRectangleBorder(
                side: BorderSide(width: 1, color: Colors.grey),
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
              iconColor: const Color(0xff008738),
              collapsedIconColor: Colors.black,
              childrenPadding: const EdgeInsets.all(8.0),
              initiallyExpanded:
                  _expandedTileIndex == ind, // Track expanded state
              onExpansionChanged: (bool expanded) {
                setState(() {
                  _expandedTileIndex =
                      expanded ? ind : null; // Update the state
                });
              },
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    CircularPercentIndicator(
                      circularStrokeCap: CircularStrokeCap.round,
                      animation: true,
                      radius: 75,
                      percent: (score["accuracy"] / 100).clamp(0.0, 1.0),
                      progressColor: const Color(0xff008730),
                      lineWidth: 15,
                      center: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${score["accuracy"] ?? 0}',
                            textScaler: const TextScaler.linear(1.0),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.logoGreen.withOpacity(0.6),
                              fontSize: 17,
                            ),
                          ),
                          const Text(
                            "Accuracy",
                            textScaler: TextScaler.linear(1.0),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        const SizedBox(height: 10),
                        RichText(
                          textScaler: const TextScaler.linear(1.1),
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                alignment: PlaceholderAlignment.middle,
                                child: Container(
                                  width: 14.0,
                                  height: 14.0,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.logoGreen,
                                  ),
                                ),
                              ),
                              TextSpan(
                                text: "  Accuracy",
                                style: TextStyle(
                                    color:
                                        AppColors.logoGreen.withOpacity(0.6)),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '${score["accuracy"] ?? 0}%',
                          textScaler: const TextScaler.linear(1.0),
                          style: const TextStyle(fontSize: 17),
                        ),
                        RichText(
                          textScaler: const TextScaler.linear(1.1),
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                alignment: PlaceholderAlignment.middle,
                                child: Container(
                                  width: 14.0,
                                  height: 14.0,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.logoYellow,
                                  ),
                                ),
                              ),
                              TextSpan(
                                text: "  Duration",
                                style: TextStyle(
                                    color:
                                        AppColors.logoGreen.withOpacity(0.6)),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '${score["duration"] ?? 0} sec',
                          textScaler: const TextScaler.linear(1.0),
                          style: const TextStyle(fontSize: 17),
                        ),
                      ],
                    )
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
